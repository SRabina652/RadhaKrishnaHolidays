
<?php $__env->startSection('title',"Display Days Descriptions"); ?>
<?php $__env->startSection('content'); ?>
<style>
   .custome1 {
      background-color: #9e9e9e;
   }
</style>

<div class="container-fluid">
   <h1>Display Days Descriptions</h1>
   <div class="mt-5">
      <table class="table">
         <thead class="bg-success text-white fw-bold">
            <th>pakage name</th>
            <th>Day Number</th>
            <th>Day Description</th>
            <th>Edit</th>
            <th>Delete</th>
         </thead>
         <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
               <td class="align-middle"><?php echo e($day->pakage?->pakageName); ?></td>
               <td class="align-middle"><?php echo e($day->days); ?></td>
               <td class="align-middle"><?php echo e($day->DayDescription); ?></td>
               <td><a href="<?php echo e(route('dayDesc.edit',$day->day_description_id)); ?>" class="btn btn-light">Edit</a></td>
               <td>
                  <form action="<?php echo e(route('dayDesc.delete',$day->day_description_id)); ?>" method="POST">
                     <?php echo csrf_field(); ?>
                     <?php echo method_field('DELETE'); ?>
                     <button type="submit" class="btn btn-light" onclick="return confirm('Are you sure you want to delete')"> Delete
                     </button>
                  </form>
               </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
      </table>
      <div class="d-flex">
         <div class="mx-auto">
            <?php echo $data->links(); ?>

         </div>
      </div>
   </div>
</div>
<script src="<?php echo e(url('js/changebtn.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelProjects\RadhaKrishnaTravel\resources\views/DaysDescription/display.blade.php ENDPATH**/ ?>