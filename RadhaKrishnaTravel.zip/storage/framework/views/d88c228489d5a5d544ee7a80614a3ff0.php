
<?php $__env->startSection('title',"Display Pakages"); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-1">
<?php if($success = \Session::get('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
   <?php echo e($success); ?>

   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?>
  <h3>Display Products</h3>
<?php if($pakages): ?>
<?php if (isset($component)) { $__componentOriginalbe5c8a4058f190ae75ec795601ac63b1 = $component; } ?>
<?php $component = App\View\Components\DisplayPakages::resolve(['pakages' => $pakages] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('display-pakages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DisplayPakages::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe5c8a4058f190ae75ec795601ac63b1)): ?>
<?php $component = $__componentOriginalbe5c8a4058f190ae75ec795601ac63b1; ?>
<?php unset($__componentOriginalbe5c8a4058f190ae75ec795601ac63b1); ?>
<?php endif; ?> 
<?php endif; ?>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelProjects\RadhaKrishnaTravel\resources\views/admin/display.blade.php ENDPATH**/ ?>