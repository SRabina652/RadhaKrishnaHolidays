<div class="mt-5">
    <table class="table">
        <thead class="bg-success text-white fw-bold">
            <th>Pakage Name</th>
            <th>pakage Price</th>
            <th>Description</th>
            <th>Pakage Days</th>
            <th>Pakage Image</th>
            <th>Edit</th>
            <th>Delete</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pakages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="align-middle"><?php echo e($product->pakageName); ?></td>
                <td class="align-middle">$ <?php echo e($product->price); ?></td>
                <td class="align-middle"><?php echo e($product->Description); ?></td>
                <td class="align-middle"><?php echo e($product->totalDays); ?> days</td>
                <td class="align-middle"><img src="<?php echo e(asset('uploads/' .$product->pakageImage)); ?>" class="img-thumbnail" height="50" width="50"></td>
                <td><a href="<?php echo e(route('pakages.edit',$product->id)); ?>" class="btn btn-light">Edit</a></td>
                <td>
                    <form action="<?php echo e(route('pakages.delete',$product->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-light" onclick="return confirm('Are you sure you want to delete')"> Delete
                        </button>
                    </form>
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="d-flex">
        <div class="mx-auto">
            <?php echo $pakages->links(); ?>

        </div>
    </div>
</div><?php /**PATH D:\laravelProjects\RadhaKrishnaTravel\resources\views/components/display-pakages.blade.php ENDPATH**/ ?>