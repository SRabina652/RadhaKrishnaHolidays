
<?php $__env->startSection('title',"Add Pakages"); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-2 px-1">
<?php if($success = \Session::get('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
   <?php echo e($success); ?>

   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?>
  <h1 class="text-center">Add Pakages</h1>
  <form action="<?php echo e(route ('pakages.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
      <label for="exampleInputName" class="form-label">Pakage Name</label>
      <input type="text" class="form-control" name="pakageName" value="<?php echo e(old('pakageName')); ?>">
      <?php $__errorArgs = ['pakageName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
      <label for="exampleInputprice" class="form-label">Pakage Price</label>
      <input type="number" step="any" class="form-control" name="price" value="<?php echo e(old('price')); ?>" />
      <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mb-3">
      <label for="exampleInputquantity" class="form-label">Time of Pakage</label>
      <input type="number" class="form-control" name="totalDays" value="<?php echo e(old('totalDays')); ?>">
      <?php $__errorArgs = ['totalDays'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
      <label for="exampleInputImage" class="form-label">Pakage Image</label>
      <input type="file" class="form-control" name="pakageImage" value="<?php echo e(old('pakageImage')); ?>">
      <?php $__errorArgs = ['pakageImage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
      <label for="exampleInputName" class="form-label">Short Description</label>
      <textarea type="text" class="form-control" name="Description" value="<?php echo e(old('Description')); ?>" rows="4" cols="40"></textarea>
      <?php $__errorArgs = ['Description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <div class="text-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <button type="submit" class="btn btn-success">Submit</button>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin-dash-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravelProjects\RadhaKrishnaTravel\resources\views/admin/index.blade.php ENDPATH**/ ?>