@extends('layouts.bodytemplate')
@section('title',"About | RadhaKrishnaHolidays")
@section('content')
<!-- About Us -->

@endsection